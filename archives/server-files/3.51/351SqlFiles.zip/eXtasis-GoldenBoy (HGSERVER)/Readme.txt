Siementech's Helbreath Game Server 3.51 build 521
a.k.a 3.61 Heldenian

Released by GoldenBoy, hacked from HBChina by Goldenboy
   Thanks to Farjat for sharing his access

*  Do not trust HB Nemesis, they don't want you to have better files than them  *

- Speed Hack warning can be found in Events.log file.
- MapData txt files could contain some edited configuration.
- Extract 3.51 MapData AMD files in MapData folder.
- Heldenian and Apocalypse commands can be found using a hex editor with the binarie

I Hope people will work in this file like Aryes to allow the community improve itself.
This file and much more soon in www.extasis.net

Regards, GoldenBoy



